# De-identification - Santeon CarePlan Implementation Guide v0.1.0

## De-identification

## Overview

De-identification in SIM on FHIR removes or transforms identifying information before hospital data leaves the institution for secondary use. This is **pseudonymisation** under the GDPR: the exported data cannot be traced back to an individual without additional information that the hospital retains and does not share.

This page describes how de-identification is controlled through three layers, how the rules are defined, and how conformance is validated before any data is exported.

### Three layers of control

Field-level control over an export is governed by three distinct layers. Each layer has a single responsibility, and each operates on the output of the layer above it.

**Layer 1 — Profile: what **can** be present.** The FHIR profile referenced by the export defines the full set of elements that may ever appear in a resource. An element that is not part of the profile can never appear in an export. This is the outer boundary — the profile is the upper limit of what is possible.

**Layer 2 — Export query: what **goes**.** Within the bounds of the profile, the export query selects — per resource type, using `_elements` and `_typeFilter` — which elements are included and which matching records are included in this specific export. `_elements` limits the fields; `_typeFilter` limits the records by their search criteria. Both are part of the export's selection and must be considered when determining what can leave the institution.

**Layer 3 — De-identification: **how** it is transformed.** For every element the query selects, a de-identification rule determines how that element is transformed on its way out: hashed, date-shifted, age-clamped, floored to the first of the month, or deliberately left intact. De-identification never removes elements — removal is the query's job, not the ruleset's.

### Core principles

The model rests on four rules that together guarantee no selected element or filter leaves the hospital without an explicit, documented decision.

**Every selected element must be covered.** Each element selected by the export query must be covered by a de-identification rule — either a rule that names its path specifically, or a broad rule whose path expression matches it (for example, `**.ofType(date)` covers every element of type `date`). An element with no covering rule is a validation error: the export request cannot be released.

**Every filter must be covered.** Each `_typeFilter` is part of the export definition and must be covered by an explicit filter rule. The rule must specify how the filter's search parameters and values are handled, including whether identifying values are transformed consistently with the corresponding released data. A filter with no covering rule is a validation error; filters are not exempt merely because they select records rather than elements.

**`none` is allowed, but must be justified.** An element may be exported unchanged, but only through an explicit `none` action carrying an `exceptionReason` that documents why the element is safe to release intact. There is no silent pass-through — leaving an element unchanged is always a deliberate, recorded choice.

**Rules that match nothing are ignored.** A de-identification rule whose path matches no element selected by the query has no effect and produces no error. This keeps a shared standard ruleset usable across exports that select different subsets of elements.

**Coverage is made visible.** For every export, coverage can be shown element by element and filter by filter: each selected element or filter, the rule that covers it, and the resulting action. This lets a privacy officer confirm, at review time, that every part of the export is accounted for.

-------

## De-identification actions

Every de-identification rule specifies an `action`. The action determines how the element is transformed, and which parameters the rule must carry. See the [DeidentificationRuleset](StructureDefinition-deidentification-ruleset.md) logical model and the [action code system](CodeSystem-deidentification-action-cs.md) for the normative definitions; the Logical Model's invariants enforce these constraints so that an invalid combination fails validation before use.

### none

The element is exported unchanged. Because unchanged release of a selected element is always a deliberate decision, `none` requires an `exceptionReason`.

| | | |
| :--- | :--- | :--- |
| `exceptionReason` | `1..1` | Documents why this element is safe to release intact |

Use `none` for elements that carry no identifying risk and whose clinical value depends on exact preservation — coded values such as SNOMED CT, LOINC, DBC, or UCUM units, and boolean flags.

```
{
  "path": "Observation.code",
  "action": "none",
  "exceptionReason": "Coded concept (LOINC); no identifying information, exact value required for analysis"
}

```

### hash

The element value is replaced by an HMAC hash. Used for identifiers and for the references that point to them. A hash rule on a resource's `id` also rewrites every reference to that resource type, anywhere in the export, to the same hash — automatically, not through a declared list of reference paths. There is no legitimate case for hashing a resource's `id` but leaving some references to it unrewritten: that would either leak the original id or break referential integrity, so the rewrite applies uniformly to `Observation.subject`, `RelatedPerson.patient`, `CarePlan.author`, or any other element referencing that resource type, whatever it happens to be called.

| | | |
| :--- | :--- | :--- |
| `algorithm` | `1..1` | Hash algorithm, e.g.`hmac-sha256` |

The seed for the HMAC changes per delivery, so the same patient hashes to different values across separate exports — deliveries cannot be linked to one another. See [Pseudonymisation and the per-export seed](#pseudonymisation-and-the-per-export-seed).

```
{
  "path": "Patient.id",
  "action": "hash",
  "algorithm": "hmac-sha256"
}

```

### shift

Date and dateTime values are moved by a random offset. The offset is derived deterministically per patient per delivery, so all dates for one patient move by the same amount within a run — preserving the intervals between events — while differing across patients and across deliveries.

| | | |
| :--- | :--- | :--- |
| `maxDays` | `1..1` | Maximum absolute shift in days; the offset is drawn from ±`maxDays`, never zero |

The offset is shared between related patients — for example mother and child — so that temporal relationships across linked records remain consistent.

```
{
  "path": "**.ofType(date)",
  "action": "shift",
  "maxDays": 15
}

```

### clamp-age

Applies to a birth date. Birth dates that imply an age outside the given range are brought to the boundary, so that outliers (very young or very old patients) cannot be singled out.

| | | |
| :--- | :--- | :--- |
| `minAge` | `1..1` | Lower age bound in years |
| `maxAge` | `1..1` | Upper age bound in years |
| `exceptionReason` | `0..1` | Required when overriding the standard range for a dataset |

The standard range is 18–85. A dataset that needs a different range must state why, through `exceptionReason` — for example a stroke (CVA) cohort extending the upper bound to 91, or a maternity cohort lowering the minimum to 0.

```
{
  "path": "Patient.birthDate",
  "action": "clamp-age",
  "minAge": 0,
  "maxAge": 91,
  "exceptionReason": "CVA dataset; stroke cohort requires extended upper age bound"
}

```

### first-of-month

Floors a date to the first day of its month, removing day-level precision while keeping month and year. Applies to any `date` element, not only `Patient.birthDate`; birth date is the most common target, but admission months or other coarse dates may use it too.

| | | |
| :--- | :--- | :--- |
| **(none)** |   | No parameters |

```
{
  "path": "Patient.birthDate",
  "action": "first-of-month"
}

```

-------

## Applying multiple rules to one element

More than one rule may target the same element. When they do, they are applied in a fixed order regardless of the order they appear in the ruleset, so the outcome is deterministic:

1. **`shift`**— move the date by the per-patient offset
1. **`first-of-month`**— floor the (shifted) date to the first of its month
1. **`clamp-age`**— bound the resulting age to the allowed range

This order is deliberate. Shifting first keeps intervals intact; flooring next removes day precision; clamping last ensures the final released value respects the age bounds no matter what the earlier steps produced. The `priority` field on a rule is available for finer control, but for date elements this canonical order is the default and covers the standard cases.

```
① shift          2024-03-22  →  2024-03-09   (offset −13 days)
② first-of-month 2024-03-09  →  2024-03-01
③ clamp-age      age from 2024-03-01 within 18–85?  →  keep / bound

```

For a plain date element (not a birth date) that has both a shift and a first-of-month rule, the same order applies: shift first, then floor. The `clamp-age` step is birth-date specific, since only a birth date implies an age.

-------

## The standard ruleset and per-export overrides

**This section is non-normative. It describes one convenient way to produce a conforming effective ruleset — the approach taken by FENIX, the Santeon reference implementation.**

### One standard, shipped with the IG

The IG publishes a single **standard de-identification ruleset** as a conformance resource: the [`santeon-default`](Binary-santeon-default.md) instance of the `DeidentificationRuleset` Logical Model, versioned alongside the IG and addressable by canonical URL (`https://ig.santeon.nl/sim-on-fhir/DeidentificationRuleset/santeon-default`). It defines the default treatment for the elements common to every Santeon export — identifiers, dates, birth date.

Every export inherits this ruleset by default. An export that is happy with the defaults writes no rules of its own; it simply references the standard set.

Reading it: patient identifiers are hashed; every date is shifted by up to 15 days; birth date is additionally floored to the first of its month and then clamped to the 18–85 age range. This is the baseline every export starts from.

### Overriding per export

An export request references the standard set as its `base` and, where it needs to differ, lists `overrides`. The override is the human-authored source; it is resolved against the base to produce the effective ruleset.

An override interacts with the base by **path and action**:

| | |
| :--- | :--- |
| Override path + action matches a base rule | Override**replaces**that base rule |
| Override path is new (no base rule for it) | Override is**added**on top of the base |
| Override sets`action: none`on a base path | Base rule for that path is**disabled**(element released intact — reason required) |

```
# geboortezorg-2024.yaml — maternity dataset

de-identification:
  base: "https://ig.santeon.nl/sim-on-fhir/DeidentificationRuleset/santeon-default|0.1.0"
  overrides:
    - path: "Patient.birthDate"
      action: "clamp-age"
      minAge: 0
      maxAge: 45
      exceptionReason: "Maternity cohort; includes newborns and excludes patients over 45"

```

Here the maternity export keeps everything from the standard set — the hash rules, the date shift, the first-of-month flooring — and changes only the age clamp, from 18–85 to 0–45. Every other rule is inherited untouched.

### Resolving base + overrides into the effective ruleset

The base and the overrides are merged, by path and action, into a single **effective ruleset** — the self-contained resource that lists every rule actually in force. This effective ruleset is the artifact the IG standardises (see [Conformance](#conformance)); the base-plus-override form is input that produces it.

```
Standard ruleset (base)            Per-export overrides
santeon-default v0.1.0             geboortezorg-2024
  Patient.id → hash                  Patient.birthDate → clamp 0–45
  Patient.identifier → hash            (exceptionReason: maternity cohort)
  **.ofType(date) → shift 15
  Patient.birthDate → first-of-month
  Patient.birthDate → clamp 18–85
            │                                │
            └────────────  merge  ───────────┘
                    by path + action
                          │
                          ▼
        Effective ruleset (self-contained)
          Patient.id → hash                    (inherited)
          Patient.identifier → hash            (inherited)
          **.ofType(date) → shift 15           (inherited)
          Patient.birthDate → first-of-month   (inherited)
          Patient.birthDate → clamp 0–45       ← REPLACED by override

```

-------

## Conformance

**This section is **normative**. It defines the artifacts this IG standardises and the properties a conforming export must have. It does not prescribe how a server produces the artifacts or applies the rules — only what is exchanged and what must be true of the exported data.**

### The export is described by two resources

A conforming export is fully described by two FHIR resources, exchanged together:

1. **The export `Parameters`** — a standard [FHIR Bulk Data](https://hl7.org/fhir/uv/bulkdata/) `Parameters` resource that defines **what is requested**: `_type` (which resource types), `_typeFilter` (which records within a type and the filters applied to them), and **`_elements`** (which elements of each type are released). `_elements` and `_typeFilter` are core Bulk Data parameters and need no extension by this IG.
1. **The effective `DeidentificationRuleset`** — a fully-resolved instance of the [`DeidentificationRuleset`](StructureDefinition-deidentification-ruleset.md) Logical Model that defines **how each released element is transformed**.

Neither resource is sufficient alone. The `Parameters` state which elements leave the hospital but not how they are protected; the ruleset states how elements are transformed but not which are requested. Only together do they describe the export completely — and only together can coverage be checked.

```
Parameters (_type, _typeFilter, _elements)   →  WHAT is released
        +
DeidentificationRuleset (effective)          →  HOW each element is transformed
        =
        complete, checkable export

```

### The effective ruleset is self-contained

"Effective" means fully resolved: the `DeidentificationRuleset` carries the actual rules that apply, with no reference to a base ruleset plus a set of differences. Any layering a producer uses to arrive at it — a shared default, per-export overrides, inheritance — is resolved before exchange. A consumer receives one `DeidentificationRuleset` and needs nothing further to know how the data was de-identified.

A conforming effective `DeidentificationRuleset`:

* validates against the `DeidentificationRuleset` Logical Model, including all per-action invariants;
* contains no rule with `action = none` that lacks an `exceptionReason`.

### Coverage — binding the two resources

**Coverage is the requirement that binds `Parameters` to the ruleset.** For every element released by the export — every element named or implied by `_elements`, for every type in `_type` — and for every `_typeFilter` used by the export, the effective `DeidentificationRuleset` must contain at least one rule that covers it. Filter coverage includes the filter parameter and its value or expression; a filter must not expose an identifying value or create a selection that cannot be justified by the ruleset.

**Coverage is hierarchical.** A rule covers the element its `path` names **and every element beneath it**. A rule on a composite element therefore covers its whole subtree: a `none` rule on `Observation.code` covers `Observation.code.coding`, `Observation.code.coding.system`, `Observation.code.coding.code`, and any other descendant, without a separate rule for each. A released element is covered when a rule exists on that element **or on any of its ancestors**. A rule may also cover by a path expression that matches across the tree — for example `**.ofType(date)` covers every `date` element wherever it occurs.

An export whose `Parameters` release an element that is covered by no rule — neither on the element itself, nor on any ancestor, nor by a matching expression — is **non-conformant**. The data must not be released in that state.

Because coverage descends, a consumer does not need to expand `_elements` down to every leaf to check conformance: it is enough that each released path is covered at some level at or above it. A rule on a selected composite element discharges the requirement for everything that element contains.

### Which rule applies — most specific wins

Coverage says an element is **protected**; it does not by itself say **how**, because more than one rule can cover the same element — a broad ancestor rule and a narrower descendant rule at once. The transformation applied to an element is the one from **the most specific covering rule**: the rule whose `path` is deepest along that element's own path.

A rule on an ancestor sets the default for its subtree; a more specific rule deeper in the tree overrides it locally, for the element it names and that element's own descendants.

```
Rule A:  Observation.code              → none         (covers the whole code subtree)
Rule B:  Observation.code.coding.code  → hash         (covers just this leaf and below)

Applied:
  Observation.code.text                → none   (nearest ancestor rule is A)
  Observation.code.coding.system       → none   (nearest ancestor rule is A)
  Observation.code.coding.code         → hash   (rule B is more specific than A)

```

This is the same "specific over general" principle the ruleset uses to order execution — `Patient.birthDate` taking precedence over `**.ofType(date)` — now stated for coverage as well: a rule at any level covers its subtree, and the deepest rule on any given path determines the action.

> Where the deepest covering rule is a path expression rather than a named path (for example `**.ofType(date)`), it competes on the specificity of the element it matches: a rule naming `Patient.birthDate` directly is more specific than `**.ofType(date)` for that element, and wins.

Note that when the deepest covering rule is a `none`, all descendants inherit that `none` — the whole subtree is released intact, and the single `exceptionReason` on that ancestor rule accounts for the entire subtree. A `none` high in the tree therefore covers a great deal; this is intended (one reason for a whole coded concept, not one per sub-element) but worth attention at review.

### What this IG does not constrain

To keep the model implementable on any FHIR server, the following are **out of scope** of the normative content:

* how the `_elements` and `_typeFilter` selections and the effective ruleset are authored or assembled (layering, defaults, overrides, templating);
* the file formats, repositories, or review processes a producer uses;
* the orchestration of an export run ja (how it is triggered, polled, transported);
* whether coverage is enforced ahead of time or by construction.

A server conforms by exchanging a valid `Parameters` and a valid effective `DeidentificationRuleset`, and by releasing data that satisfies coverage — regardless of how it reaches that result.

-------

## Implementation notes (non-normative)

**This section describes how **FENIX**, the Santeon reference implementation, produces a conforming export. It is illustrative. Another server may reach the same result by entirely different means; nothing here is required for conformance.**

### Authoring: base plus overrides

FENIX does not author the effective ruleset directly. It starts from the shared standard ruleset published with the IG (`santeon-default`) and applies per-export overrides expressed in YAML. Overrides replace, add, or disable rules by path and action. This keeps each export request short — an export states only how it differs from the default.

The base-plus-override YAML is FENIX input, not an IG artifact. It is one convenient way to produce an effective ruleset; it is never exchanged and carries no normative status.

### Generation: resolving to the exchanged resources

`fenix generate` resolves base and overrides into the effective `DeidentificationRuleset`, and writes the `Parameters.json` carrying `_type`, `_typeFilter` and `_elements`. Together these two generated resources are the normative pair; the YAML that produced them is FENIX input and is not exchanged.

```
requests/
└── geboortezorg-2024/
    ├── geboortezorg-2024.yaml           ← FENIX input: base + overrides (non-normative)
    ├── Group.json                        ← generated
    ├── Parameters.json                   ← generated: _type, _typeFilter, _elements (IG artifact)
    └── DeidentificationRuleset.json      ← generated: effective ruleset (IG artifact)

```

A server that already holds effective rulesets — hand-authored, templated, or produced by other tooling — needs none of this. It exchanges the `Parameters` and the `DeidentificationRuleset` and exports conforming data; the path it took is its own concern.

### Coverage report

To make the coverage property auditable, FENIX emits a coverage report for each export: every released element, the rule that covers it, and the resulting action. A reviewer confirms at a glance that no element is uncovered and that every `none` carries a reason.

The report is a FENIX convenience, not an IG artifact — it is one way to demonstrate the coverage property the IG requires of the data. Another implementation might prove coverage differently, or enforce it by construction and produce no report at all.

| | | |
| :--- | :--- | :--- |
| `Patient.id` | `Patient.id` | hash |
| `Patient.birthDate` | `Patient.birthDate`(×2) | first-of-month → clamp-age |
| `Observation.effectiveDateTime` | `**.ofType(date)` | shift |
| `Observation.code` | `Observation.code` | none (reason recorded) |

-------

## Pseudonymisation and the per-export seed

**This section is **normative** for the properties an export must exhibit (the seed behaviour), and marks clearly what is **out of scope** (the key and seed material themselves).**

### Why hashing is keyed

Identifiers are removed by replacing them with an HMAC (see the [`hash`](#hash) action). HMAC is a **keyed** hash: the output depends on both the input value and a secret key. This is deliberate. A plain, unkeyed hash of an identifier would be reversible by anyone who can hash candidate values — the space of BSNs or patient numbers is small enough to enumerate. Keying the hash with a secret the attacker does not hold defeats that: without the key, the output cannot be linked back to the input.

The result is **pseudonymisation** under the GDPR, not anonymisation. The data cannot be re-identified from its own contents, but a party holding the key and the source data can reverse it. That key is the "additional information" the regulation requires be kept separately — and this IG requires exactly that separation.

### The per-export seed

Each export derives its HMAC seed freshly, per export run. The seed governs both the identifier hashing and the per-patient date-shift offset. Two properties follow, and a conforming export **must** exhibit both:

**Consistent within a run.** Within a single export, the same source identifier always hashes to the same value, and all of one patient's dates shift by the same offset. Referential integrity is preserved — a hashed `Patient.id` and every reference to that patient anywhere in the export resolve to the same value — and temporal relationships between a patient's events are kept intact. Related patients (for example mother and child) share the offset, so cross-record intervals also survive.

**Unlinkable across runs.** Because the seed changes per export, the **same** patient exported in two separate runs hashes to two **different** values, and their dates shift by different offsets. A party holding two deliveries cannot tell that a record in one corresponds to a record in the other by comparing hashes or dates. Deliveries are not linkable to each other from their contents alone.

```
Patient BSN 123456789

Export run A (seed Sₐ):   hash → 8f3c1d…    birthDate shift −11d
Export run B (seed S_b):  hash → b0a927…    birthDate shift +6d

Same patient, two runs, no common value to link them on.

```

This unlinkability is a required property, not an implementation detail: an export that reused a seed across runs — producing stable hashes that let deliveries be joined — would not conform.

### Key and seed are out of scope

The HMAC key, and any seed derived from it, are **secrets held inside the hospital**. This IG does not define, carry, or exchange them, and a conforming export **must not** include them:

* the key **must not** appear in any exchanged resource — not in the `DeidentificationRuleset`, not in the `Parameters`, not in a `Provenance`, nowhere in the export payload;
* the key **must not** be committed to version control or embedded in any authored artifact;
* the key is held only in the hospital's own secret storage (an environment secret, a vault) and never crosses the institutional boundary.

Placing the key anywhere it travels with the data would defeat pseudonymisation entirely — the secret that protects the data would accompany the data it protects. Keeping it strictly inside the hospital is what makes the exported data safe to release.

The **seed** is likewise never exchanged. Only its **effect** leaves the hospital — the hashed values and shifted dates in the output. From those, the seed cannot be recovered.

### Internal reversibility — the run identifier

Pseudonymisation must be reversible by the hospital when there is a lawful basis to re-identify a patient. This IG supports that without exposing any secret, by separating the two things reversal needs: a **public label** that may travel, and the **secret key** that never does.

Each export run carries a **run identifier** — an opaque, non-secret value that names the run. The run identifier reveals nothing on its own: it is not derived from patient data and cannot be used to compute a hash or an offset. It may appear in a `Provenance` resource or in export metadata, and it may be exchanged.

Reversal is possible only inside the hospital, by combining three things it alone holds together:

```
run identifier   (names which run → which seed generation)
      +
HMAC key         (the hospital-held secret, never exported)
      +
source data      (the original identifiers, held in the EPD)
      =
re-identification of a specific patient — inside the hospital only

```

A privacy officer with access to all three can, for a named run, reconstruct the seed and reverse a specific hash back to the source patient — and, once the patient is identified, read any other field (a shifted date, a clamped age) directly from the source data, the same way any un-exported field would be read. A party outside the hospital holds at most the run identifier and the de-identified output — never the key — and so can never reverse anything. The run identifier makes reversal **auditable and addressable** ("reverse patient X in run f3a1c8") without making it **possible** for anyone lacking the key.

> The run identifier is a non-secret handle, not key material. Exchanging it does not weaken pseudonymisation. The seed itself is derived from the key and the run inside the hospital and is never stored in or alongside an exchanged resource.

### Reversing a hash

Reversal does not work by decrypting a stored value — an HMAC cannot be decrypted. It is recomputed from the key, not looked up: to re-identify a hashed `Patient.id`, the privacy officer takes a candidate source identifier from the EPD, recomputes `HMAC(key, candidate)` under the reconstructed seed, and compares the result to the hash in the exported data. A match confirms the candidate is the source patient. This is the same forward computation performed at export time — reversal is recomputation and comparison, not inversion.

`hash` is the only action this IG requires to be reversible. It is the anchor: once a record's patient is identified this way, every other field on that record — however it was transformed on export — is available in the source system, without needing to be inverted at all. See below.

### shift, clamp-age, and first-of-month: recovered via identity, not inversion

Only `hash` carries a reversal requirement. For every other transformed field, the path back to the original value is always the same: reverse the `hash` on `Patient.id` to identify the patient, then read the field from the EPD. None of these actions need their own inversion procedure.

**`shift`.** The per-patient offset is derived deterministically from the seed and a linking identifier (see the construction below) so that, within one export, all of one patient's dates move by the same amount — preserving intervals — while varying across patients and across runs. That determinism exists to make the **forward** shift consistent, not to make the shift invertible; the offset is never exported, stored, or looked up, and this IG does not standardise or require a way to recompute it. Unlike `clamp-age` and `first-of-month`, a shifted date is not inherently lossy — in principle, whoever holds the key and can reconstruct `(seed, linkId)` could recompute the offset and subtract it back out — but the IG places no weight on that possibility: the normative path to a patient's true date is the EPD lookup above, exactly as for every other field.

**`clamp-age` and `first-of-month`.** These are lossy generalisations, not transformations, and here inversion genuinely is impossible, key or no key. `first-of-month` discards the day of the month entirely — `2024-03-22` and `2024-03-09` both become `2024-03-01`, and nothing in the output distinguishes them. `clamp-age` discards precision only for birth dates **outside** the configured range, replacing them with the boundary — every source birth date implying an age above `maxAge` (or below `minAge`) collapses to the same boundary value. No amount of computation recovers a value that was discarded rather than transformed. This is not a gap: the export was never meant to carry enough information to reconstruct itself, only what the stated analytical purpose requires (an age band, a cohort month), while the EPD remains the source of truth for anything more precise.

`none` needs no reversal at all — the exported value already is the source value.

| | | |
| :--- | :--- | :--- |
| `hash` | Yes, with the key | Recompute`HMAC(key, candidate)`and compare |
| `shift` | Not required (technically possible with the key, but unused) | Re-identify the patient (via`hash`), then read the date from the EPD |
| `clamp-age` | No — the information is gone, key or not | Re-identify the patient (via`hash`), then read`birthDate`from the EPD |
| `first-of-month` | No — the information is gone, key or not | Re-identify the patient (via`hash`), then read the date from the EPD |
| `none` | N/A | Value was never altered |

### Illustrative construction of the shift offset (non-normative)

**This shows one way to derive a per-patient offset with the required forward properties. It is not a normative algorithm — any deterministic, keyed construction with the same properties conforms.**

```
digest  = HMAC-SHA256(seed, linkId)              // 32 bytes
N       = first 4 bytes of digest, as an unsigned integer
k       = N mod (2 · maxDays)                    // k ∈ [0, 2·maxDays − 1]
offset  = k < maxDays ? (k − maxDays) : (k − maxDays + 1)

```

The final step maps the `2·maxDays` possible values of `k` onto `[−maxDays, −1] ∪ [1, maxDays]` — skipping zero, exactly as the `shift` action requires. `shiftedDate = originalDate + offset` days.

**`linkId` is what makes the mother/child case work.** For a standalone patient, `linkId` is that patient's own source identifier — each patient gets an independent offset. For related patients who must move together, the source data already expresses the link explicitly through FHIR itself: a `RelatedPerson` resource connects the two `Patient` records, with `RelatedPerson.relationship` carrying the role — mother, child (e.g. `MTH`/`CHILD` from the [relatedperson-relationshiptype](https://hl7.org/fhir/R4/valueset-relatedperson-relationshiptype.html) value set). `linkId` is resolved from that relationship rather than from either patient's own identifier — for example, the identifier of whichever patient is treated as the anchor of the pair (say, the mother) — so both the mother's and the child's `Patient` resources feed the **same** `linkId` into the same `HMAC(seed, linkId)`, and both get the **same** `offset`. This is exactly the "consistent within a run" / "shared between related patients" property described [above](#the-per-export-seed). Where a patient has no `RelatedPerson` link, `linkId` collapses to that patient's own identifier and the construction is unchanged.

-------

## Normative artifacts

The de-identification model is defined as a set of compilable FHIR Shorthand artifacts, published with this IG:

* [DeidentificationRuleset](StructureDefinition-deidentification-ruleset.md) — the Logical Model, with its per-action invariants
* [DeidentificationActionCS](CodeSystem-deidentification-action-cs.md) — the code system for `rule.action`
* [DeidentificationActionVS](ValueSet-deidentification-action-vs.md) — the value set bound to `rule.action`
* [santeon-default](StructureDefinition-deidentification-ruleset-examples.md) — the standard ruleset shipped with the IG, as a `DeidentificationRuleset` instance

Source: [`input/fsh/DeidentificationRuleset.fsh`](https://github.com/SanteonNL/sim-on-fhir/blob/main/input/fsh/DeidentificationRuleset.fsh).

