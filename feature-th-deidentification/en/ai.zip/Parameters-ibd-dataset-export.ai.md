# IBD export parameters (generated) - SIM on FHIR v0.1.0

## Parameters: IBD export parameters (generated)



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "ibd-dataset-export",
  "parameter" : [{
    "name" : "_type",
    "valueString" : "Procedure,Observation,Patient"
  },
  {
    "name" : "_typeFilter",
    "valueString" : "Procedure?code:in=https://ig.santeon.nl/sim-on-fhir/ValueSet/local-verrichting-codes-nza&date=ge2018-01-01"
  },
  {
    "name" : "_typeFilter",
    "valueString" : "Observation?code=http://loinc.org|38445-3,http://snomed.info/sct|228273003&date=ge2018-01-01"
  },
  {
    "name" : "_typeFilter",
    "valueString" : "Patient?gender=male,female"
  },
  {
    "name" : "_elements",
    "valueString" : "Procedure.code,Procedure.performed[x],Procedure.subject,Observation.code,Observation.value[x],Observation.effective[x],Observation.subject,Patient.gender,Patient.birthDate"
  }]
}

```
