# Resource SIM on FHIR



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "santeon.sim-on-fhir",
  "language" : "en",
  "url" : "https://ig.santeon.nl/sim-on-fhir/ImplementationGuide/santeon.sim-on-fhir",
  "version" : "0.1.0",
  "name" : "SanteonSimOnFhir",
  "title" : "SIM on FHIR",
  "status" : "draft",
  "date" : "2026-10-16T14:28:20+00:00",
  "publisher" : "Santeon",
  "contact" : [{
    "name" : "Santeon",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.santeon.nl"
    }]
  }],
  "description" : "How the Santeon Informatie Model (SIM) maps to FHIR: common logical models, FHIR profiles, datasets with their KPI definitions, and de-identification of exports.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "NL",
      "display" : "Netherlands"
    }]
  }],
  "packageId" : "santeon.sim-on-fhir",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.4.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "show-inherited-invariants"
      },
      {
        "url" : "value",
        "valueString" : "false"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-binary"
      },
      {
        "url" : "value",
        "valueString" : "input/static"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tx"
      },
      {
        "url" : "value",
        "valueString" : "http://decor.nictiz.nl/fhir/4.0/san-gen-"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "generate-expansion"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid-template"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid-template"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://ig.santeon.nl/sim-on-fhir/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ObservationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ObservationDefinition-od-alcohol-use.html"
      }],
      "reference" : {
        "reference" : "ObservationDefinition/od-alcohol-use"
      },
      "name" : "Alcoholgebruik",
      "description" : "Alcohol use status; the answer is a code from the valid coded value set.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Binary-alcohol-status-recorded.html"
      }],
      "reference" : {
        "reference" : "Binary/alcohol-status-recorded"
      },
      "name" : "Alcoholgebruik vastgelegd",
      "description" : "Alcohol use status recorded, with a coded answer.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-AlcoholGebruikStatusCodelijst.html"
      }],
      "reference" : {
        "reference" : "ValueSet/AlcoholGebruikStatusCodelijst"
      },
      "name" : "AlcoholGebruikStatusCodelijst",
      "description" : "Codelijst voor de gecodeerde uitslag van alcoholgebruik.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-2.16.840.1.113883.2.4.3.11.60.40.2.7.3.2--20200901000000.html"
      }],
      "reference" : {
        "reference" : "ValueSet/2.16.840.1.113883.2.4.3.11.60.40.2.7.3.2--20200901000000"
      },
      "name" : "AlcoholGebruikStatusCodelijst",
      "description" : "AlcoholGebruikStatusCodelijst",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SIMAlgemeneMeting.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SIMAlgemeneMeting"
      },
      "name" : "Algemene meting (model)",
      "description" : "Logisch model voor een algemeneMeting binnen het Santeon Informatiemodel.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ObservationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ObservationDefinition-od-calprotectin.html"
      }],
      "reference" : {
        "reference" : "ObservationDefinition/od-calprotectin"
      },
      "name" : "Calprotectine (feces)",
      "description" : "Faecal calprotectin, numeric result in microgram per gram.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-2.16.840.1.113883.2.4.3.11.60.124.11.140--20240925070229.html"
      }],
      "reference" : {
        "reference" : "ValueSet/2.16.840.1.113883.2.4.3.11.60.124.11.140--20240925070229"
      },
      "name" : "CareplanCategoryCodelijst",
      "description" : "CareplanCategoryCodelijst",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-condition-san.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/condition-san"
      },
      "name" : "Condition (SAN)",
      "description" : "**De-identificatie:**\n- identifier → hashed\n- subject → hashed",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-dataset-definition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/dataset-definition"
      },
      "name" : "Dataset definition (model)",
      "description" : "One dataset (for example IBD or COPD): the cohort that forms the Group, and the\nKPI definitions whose data the export releases. The generator resolves a dataset\ninto a `Group` (cohort as bulk-data `member-filter`s) and a `Parameters`\n(`_type`, `_typeFilter`, `_elements`), and renders the whole definition as a\nreadable page.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SIMDBC.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SIMDBC"
      },
      "name" : "DBC/Zorgtraject (model)",
      "description" : "Logisch model voor een DBC binnen het Santeon Informatiemodel.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-deidentification-action-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/deidentification-action-cs"
      },
      "name" : "De-identification Action Code System",
      "description" : "The transformations a de-identification rule may apply to an element.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-deidentification-action-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/deidentification-action-vs"
      },
      "name" : "De-identification Action Value Set",
      "description" : "Allowed values for a de-identification rule's action.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-deidentification-ruleset.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/deidentification-ruleset"
      },
      "name" : "De-identification ruleset (model)",
      "description" : "A fully-resolved (effective) set of de-identification rules for one export.\nIt carries the actual rules in force, with no reference to a base ruleset\nplus differences. Together with the export Parameters (which declare the\nreleased elements via _elements), it fully describes how an export is\nde-identified.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-episodeOfCare-san.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/episodeOfCare-san"
      },
      "name" : "EpisodeOfCare (SAN)",
      "description" : "**De-identificatie:**\n- identifier → hashed\n- patient → hashed",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SIMFasering.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SIMFasering"
      },
      "name" : "Fasering (model)",
      "description" : "Logisch model voor een procesfasering binnen het Santeon Informatiemodel, bijvoorbeeld faseringen rondom een operatie.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Group"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Group-ibd-dataset-cohort.html"
      }],
      "reference" : {
        "reference" : "Group/ibd-dataset-cohort"
      },
      "name" : "IBD cohort (generated)",
      "description" : "Cohort of the IBD dataset as bulk-data member-filters.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Binary-ibd-dataset.html"
      }],
      "reference" : {
        "reference" : "Binary/ibd-dataset"
      },
      "name" : "IBD dataset",
      "description" : "Dataset for adult IBD patients.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Parameters-ibd-dataset-export.html"
      }],
      "reference" : {
        "reference" : "Parameters/ibd-dataset-export"
      },
      "name" : "IBD export parameters (generated)",
      "description" : "_type, _typeFilter and _elements of the IBD export.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-IBDSpecialismeDiagnoses.html"
      }],
      "reference" : {
        "reference" : "ValueSet/IBDSpecialismeDiagnoses"
      },
      "name" : "IBD Specialisme Diagnoses",
      "description" : "Specialisme-diagnosecombinaties die worden geselecteerd voor de IBD-dataset.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-local-specialisme-diagnose-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/local-specialisme-diagnose-codes"
      },
      "name" : "IBD Specialisme-Diagnose Combinaties",
      "description" : "Specialisme-diagnose combinaties die behoren tot het IBD-cohort.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-IBDVerrichtingenNZa.html"
      }],
      "reference" : {
        "reference" : "ValueSet/IBDVerrichtingenNZa"
      },
      "name" : "IBD Verrichtingen NZa",
      "description" : "NZa-verrichtingen die worden geselecteerd voor de IBD-dataset.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-local-zorgtype-codes.html"
      }],
      "reference" : {
        "reference" : "ValueSet/local-zorgtype-codes"
      },
      "name" : "IBD Zorgtype Codes (11 en 21)",
      "description" : "Bevat de toegestane landelijke zorgtypes 11 en 21.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-IBDAlgemeneMetingen.html"
      }],
      "reference" : {
        "reference" : "ValueSet/IBDAlgemeneMetingen"
      },
      "name" : "IBDAlgemeneMetingen",
      "description" : "Metingen die worden geselecteerd voor de IBD-dataset.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Binary-k312-scopie.html"
      }],
      "reference" : {
        "reference" : "Binary/k312-scopie"
      },
      "name" : "K3.1.2 Scopie",
      "description" : "Number of adult IBD patients with a scopie since 2018.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Binary-k363-calprotectin-before-scopie.html"
      }],
      "reference" : {
        "reference" : "Binary/k363-calprotectin-before-scopie"
      },
      "name" : "K3.6.3 Calprotectine voor scopie",
      "description" : "Share of scopies preceded by a faecal calprotectin measurement.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-kpi-definition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/kpi-definition"
      },
      "name" : "KPI definition (model)",
      "description" : "The data a KPI needs, expressed as a list of FHIR search criteria. The union of\nall KPI definitions determines the model: the generated profiles accept exactly\nthe codes and elements the KPIs ask for, and the generated export request\nselects exactly the records they filter on.\n\n**Parameter values** are FHIR search values and may contain references that the\ngenerator resolves:\n\n| Reference | Resolves to |\n|---|---|\n| `{vs:<id>}` | canonical URL of the ValueSet with that id |\n| `{od:<id>.code}` | `system|code` token(s) of the ObservationDefinition's code |\n| `{od:<id>.unit}` | `system|code` of the ObservationDefinition's quantitative unit |\n| `{od:<id>.valid}` | canonical URL of the ObservationDefinition's valid coded value set |\n| `{vs:<canonical URL>}` | a ValueSet maintained elsewhere (for example ART-DECOR), referenced by canonical |\n\nA value may also be a literal: `code:in=<canonical URL>` names an external value set, and\n`type=system|code,system|code` lists codes inline. Literal codes on a `code` parameter of a\nKPI criterion are added to the generated code value set.\n\nAnything else in curly braces, such as `{period.start}`, is a placeholder that\nthe exporter fills in at run time.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-observation-san-kpi.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/observation-san-kpi"
      },
      "name" : "Observation (SAN KPI)",
      "description" : "The one Observation profile of the model, generated from the KPI and dataset definitions. Allowed codes: ObservationCodeSanKpi. Elements nothing asks for are closed.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-observation-san.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/observation-san"
      },
      "name" : "Observation (SAN)",
      "description" : "**De-identificatie:**\n- identifier → hashed\n- subject → hashed\n- effectiveDateTime → dateshift",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-observationCode-san-kpi.html"
      }],
      "reference" : {
        "reference" : "ValueSet/observationCode-san-kpi"
      },
      "name" : "Observation code (SAN KPI)",
      "description" : "Every code a KPI definition asks for on Observation. The union of the ObservationDefinition codes and the value sets referenced by the Observation criteria of all KPI definitions.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-od-component.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/od-component"
      },
      "name" : "ObservationDefinition Component",
      "description" : "Points from a panel ObservationDefinition (e.g. blood pressure) to the ObservationDefinition of one of its components (e.g. systolic). The component's own code and unit become a constraint on Observation.component in the generated profile.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-patient-san-kpi.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/patient-san-kpi"
      },
      "name" : "Patient (SAN KPI)",
      "description" : "The one Patient profile of the model, generated from the KPI and dataset definitions. Elements nothing asks for are closed.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-patient-san.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/patient-san"
      },
      "name" : "Patient (SAN)",
      "description" : "**De-identificatie:**\n- identifier → hashed\n- birthDate →  dateshift",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SIMPatient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SIMPatient"
      },
      "name" : "Patiënt (model)",
      "description" : "Logisch model voor patiëntgegevens binnen het Santeon Informatiemodel.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-procedure-san-kpi.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/procedure-san-kpi"
      },
      "name" : "Procedure (SAN KPI)",
      "description" : "The one Procedure profile of the model, generated from the KPI and dataset definitions. Allowed codes: ProcedureCodeSanKpi. Elements nothing asks for are closed.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-procedure-san.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/procedure-san"
      },
      "name" : "Procedure (SAN)",
      "description" : "**De-identificatie:**\n- identifier → hashed\n- subject → hashed",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-procedureCode-san-kpi.html"
      }],
      "reference" : {
        "reference" : "ValueSet/procedureCode-san-kpi"
      },
      "name" : "Procedure code (SAN KPI)",
      "description" : "Every code a KPI definition asks for on Procedure. The union of the ObservationDefinition codes and the value sets referenced by the Procedure criteria of all KPI definitions.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ObservationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ObservationDefinition-od-smoking-status.html"
      }],
      "reference" : {
        "reference" : "ObservationDefinition/od-smoking-status"
      },
      "name" : "Rookstatus",
      "description" : "Tobacco smoking status (illustrative); the answers come from the Nationale Terminologieserver. No KPI uses this measurement yet, so it is not part of the generated model.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-resource-format",
        "valueCode" : "application/fhir+json"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Binary"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Binary-santeon-default.html"
      }],
      "reference" : {
        "reference" : "Binary/santeon-default"
      },
      "name" : "Santeon Standard De-identification Ruleset",
      "description" : "The default ruleset every Santeon export inherits unless overridden.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-Santeon-MetingNaamCodelijst.html"
      }],
      "reference" : {
        "reference" : "ValueSet/Santeon-MetingNaamCodelijst"
      },
      "name" : "Santeon_MetingNaamCodelijst",
      "description" : "ValueSet met metingnamen die binnen het Santeon Informatiemodel worden gebruikt.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-specialisme-diagnose-code.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/specialisme-diagnose-code"
      },
      "name" : "SpecialismeDiagnoseCode",
      "description" : "(Tijdelijke) Extensie voor SpecialismeDiagnoseCode. Deze informatie dient in een toekomstige FHIR-conforme modellering te worden ondergebracht in Condition.code.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-SIMVerrichting.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/SIMVerrichting"
      },
      "name" : "Verrichting (model)",
      "description" : "Logisch model voor een verrichting binnen het Santeon Informatiemodel.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-local-verrichting-codes-nza.html"
      }],
      "reference" : {
        "reference" : "ValueSet/local-verrichting-codes-nza"
      },
      "name" : "Verrichting Type Codes NZa (Scopie)",
      "description" : "De specifieke NZa-verrichtingencodes voor de scopie-indicator.",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "CLMs.html"
        }],
        "nameUrl" : "CLMs.html",
        "title" : "Common Logical Models (SIM)",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "profiles.html"
        }],
        "nameUrl" : "profiles.html",
        "title" : "FHIR Profiles",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "datasets.html"
        }],
        "nameUrl" : "datasets.html",
        "title" : "Datasets",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "ibd-dataset.html"
          }],
          "nameUrl" : "ibd-dataset.html",
          "title" : "IBD",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "kpi-definitions.html"
        }],
        "nameUrl" : "kpi-definitions.html",
        "title" : "KPI definitions",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "K312.html"
        }],
        "nameUrl" : "K312.html",
        "title" : "K3.1.2 Scopie",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "K363.html"
        }],
        "nameUrl" : "K363.html",
        "title" : "K3.6.3 Calprotectine voor scopie",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "deidentification.html"
        }],
        "nameUrl" : "deidentification.html",
        "title" : "De-identification",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
