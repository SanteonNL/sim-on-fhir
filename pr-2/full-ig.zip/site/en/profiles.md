# FHIR Profiles - SIM on FHIR v0.1.0

## FHIR Profiles

The Santeon FHIR profiles describe the standardised FHIR R4 representation of the SIM building blocks. A profile only adds rules for agreed FHIR requirements that its parent does not cover yet. The scope and the delivery and conversion agreements are maintained in the corresponding [SIM Logical Model](CLMs.md) and its mapping to FHIR.

### Overview

10 profiles: 1 ready for validation, 5 in progress, 4 not reviewed.

| | | | |
| :--- | :--- | :--- | :--- |
| [CarePlan (SAN)](StructureDefinition-carePlan-san.md) | [Zorgplan (SIMCarePlan)](StructureDefinition-SIMCarePlan.md) | [SIM Logical Model](StructureDefinition-carePlan-san-mappings.md) | In progress · 3 open checks |
| [Condition (SAN)](StructureDefinition-condition-san.md) | – | – | Not reviewed · 3 open checks |
| [Encounter (SAN)](StructureDefinition-encounter-san.md) | [Contact (SIMContact)](StructureDefinition-SIMContact.md) | [SIM Logical Model](StructureDefinition-encounter-san-mappings.md) | In progress · 4 open checks |
| [EpisodeOfCare (SAN)](StructureDefinition-episodeOfCare-san.md) | [DBC/Zorgtraject (SIMDBC)](StructureDefinition-SIMDBC.md) | [SIM Logical Model](StructureDefinition-episodeOfCare-san-mappings.md) | In progress · 3 open checks |
| [MedicationRequest (SAN)](StructureDefinition-medicationRequest-san.md) | [Medicatieafspraak (SIMMedicatieAfspraak)](StructureDefinition-SIMMedicatieAfspraak.md) | [SIM Logical Model](StructureDefinition-medicationRequest-san-mappings.md) | In progress · 4 open checks |
| [Observation (SAN)](StructureDefinition-observation-san.md) | [Algemene meting (SIMAlgemeneMeting)](StructureDefinition-SIMAlgemeneMeting.md) | [SIM Logical Model](StructureDefinition-observation-san-mappings.md) | In progress · 2 open checks |
| [Observation TabakGebruik (SAN)](StructureDefinition-observation-san-tabakgebruik.md) | [Tabakgebruik (SIMTabakGebruik)](StructureDefinition-SIMTabakGebruik.md) | [SIM Logical Model](StructureDefinition-observation-san-tabakgebruik-mappings.md) | Not reviewed · 3 open checks |
| [Patient (SAN)](StructureDefinition-patient-san.md) | [Patiënt (SIMPatient)](StructureDefinition-SIMPatient.md) | [SIM Logical Model](StructureDefinition-patient-san-mappings.md)·[Nictiz nl-core](StructureDefinition-patient-san-mappings.md) | Ready for validation · 1 open check |
| [Procedure (SAN)](StructureDefinition-procedure-san.md) | [Verrichting (SIMVerrichting)](StructureDefinition-SIMVerrichting.md) | [SIM Logical Model](StructureDefinition-procedure-san-mappings.md)·[Nictiz nl-core](StructureDefinition-procedure-san-mappings.md) | Not reviewed · 3 open checks |
| [QuestionnaireResponse (SAN)](StructureDefinition-questionnaireResponse-san.md) | [Vragenlijstantwoord (SIMVragenlijstAntwoord)](StructureDefinition-SIMVragenlijstAntwoord.md) | [SIM Logical Model](StructureDefinition-questionnaireResponse-san-mappings.md) | Not reviewed · 3 open checks |

### Reading the table

**Mappings** are listed in their fixed order and only where they exist; each links to the mapping page of the profile.

* **SIM Logical Model** (mapping 1) – SIM provenance and conversion per FHIR element. Generated from the logical model's mapping to FHIR; maintained there only. The **Logical Model** column is derived from this mapping.
* **Nictiz nl-core** (mapping 2) – manual technical delta analysis with the Nictiz nl-core profile (nictiz.nl.gbb 1.0.0-alpha.2). Where no technical delta is recorded, the FSH source explains why.

**Status** is the own status of each FHIR profile, chosen by review and recorded at the bottom of its FSH source. It is never taken over from a linked model or profile.

* **Not reviewed** – present, but not yet checked against the modelling convention (default).
* **In progress** – the definition and/or its mappings are being worked out or revised.
* **Ready for validation** – modelling and documentation are worked out; checks or technical validation may still be open.
* **Validated** – the agreed content reviews and technical validations have been completed and checked.
* **Open checks** – the number of `// TODO:` items in the FSH source of this definition.

The modelling convention (the fixed mapping order, delta indicators and consistency checks) is described in `docs/modelleerworkflow.md` in the project repository. Delta outcomes are recorded per element: 🟢/🟡 for Nictiz GBB and Equivalent/🟡 for Nictiz nl-core. The modelling status is recorded separately.

