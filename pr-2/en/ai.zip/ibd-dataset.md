# IBD - SIM on FHIR v0.1.0

## IBD

### IBD dataset

Gegevensset voor volwassen patiënten met inflammatoire darmziekten (IBD): scopieën en calprotectinemetingen, plus alcoholgebruik.

Version 0.1.0 · definition: [ibd-dataset](Binary-ibd-dataset.md) · generated: [Group](Group-ibd-dataset-cohort.md), [Parameters](Parameters-ibd-dataset-export.md)

-------

#### Cohort

Alle patiënten van 18 jaar of ouder op het moment van aanleveren met een actief, regulier DBC-zorgtraject (zorgtype 11 of 21) dat op of na 01-01-2018 is geopend en waarvan de specialisme-diagnose bij IBD hoort. De startdatum 01-01-2018 is bewust niet dynamisch.

A patient is in the Group when every criterion below is satisfied. Each criterion becomes one bulk-data `member-filter` modifier extension on the Group; the Bulk Data IG defines several filters as all of them having to match.

**Criterion 1: Patient**

| | |
| :--- | :--- |
| `birthdate` | `le{today-18y}` |

```
Patient?birthdate=le{today-18y}

```

**Criterion 2: EpisodeOfCare**

| | |
| :--- | :--- |
| `type:in` | `{vs:local-zorgtype-codes}` |
| `status` | `active` |
| `date` | `ge2018-01-01` |
| `diagnosis:Condition.code:in` | `{vs:local-specialisme-diagnose-codes}` |

```
EpisodeOfCare?type:in=https://ig.santeon.nl/sim-on-fhir/ValueSet/local-zorgtype-codes&status=active&date=ge2018-01-01&diagnosis:Condition.code:in=https://ig.santeon.nl/sim-on-fhir/ValueSet/local-specialisme-diagnose-codes

```

-------

#### KPI definitions

The data each KPI needs. Criteria are role-neutral; the same criterion in two KPIs is queried once.

##### K3.1.2 Scopie

`k312-scopie` · version 0.1.0 · definition: [k312-scopie](Binary-k312-scopie.md)

Aantal volwassen IBD-patiënten met een scopie-verrichting vanaf 2018.

**Criterion 1: Procedure**

| | |
| :--- | :--- |
| `code:in` | `{vs:local-verrichting-codes-nza}` |
| `date` | `ge2018-01-01` |

Resolved:

```
Procedure?code:in=https://ig.santeon.nl/sim-on-fhir/ValueSet/local-verrichting-codes-nza&date=ge2018-01-01

```

Elements: `code`, `performed[x]`, `subject`

##### K3.6.3 Calprotectine voor scopie

`k363-calprotectin-before-scopie` · version 0.1.0 · definition: [k363-calprotectin-before-scopie](Binary-k363-calprotectin-before-scopie.md)

Percentage scopieën waarbij in de 90 dagen voorafgaand aan de scopie ten minste één fecaal calprotectinemeting is uitgevoerd.

**Criterion 1: Procedure**

| | |
| :--- | :--- |
| `code:in` | `{vs:local-verrichting-codes-nza}` |
| `date` | `ge2018-01-01` |

Resolved:

```
Procedure?code:in=https://ig.santeon.nl/sim-on-fhir/ValueSet/local-verrichting-codes-nza&date=ge2018-01-01

```

Elements: `code`, `performed[x]`, `subject`

**Criterion 2: Observation**

| | |
| :--- | :--- |
| `code` | `{od:od-calprotectin.code}` |
| `date` | `ge2018-01-01` |

Resolved:

```
Observation?code=http://loinc.org|38445-3&date=ge2018-01-01

```

Elements: `code`, `value[x]`, `effective[x]`, `subject`

**Post-query filters**

* A calprotectin measurement counts only when it falls within the 90 days up to and including the start of a scopie of the same patient. A date relation between two resources cannot be expressed in a FHIR search. 
* `Observation.effective >= Procedure.performed.start - 90 days and Observation.effective <= Procedure.performed.start and Observation.subject = Procedure.subject`
 

##### Alcoholgebruik vastgelegd

`alcohol-status-recorded` · version 0.1.0 · definition: [alcohol-status-recorded](Binary-alcohol-status-recorded.md)

Is de alcoholgebruikstatus vastgelegd met een gecodeerde uitslag?

**Criterion 1: Observation**

| | |
| :--- | :--- |
| `code` | `{od:od-alcohol-use.code}` |
| `date` | `ge2018-01-01` |

Resolved:

```
Observation?code=http://snomed.info/sct|228273003&date=ge2018-01-01

```

Elements: `code`, `value[x]`, `effective[x]`, `subject`

-------

#### Included data

Data the dataset releases that does not belong to a KPI. It is part of the export and of the derived model like a KPI criterion.

**Patient**

| | |
| :--- | :--- |
| `gender` | `male,female` |

Resolved:

```
Patient?gender=male,female

```

Elements: `gender`, `birthDate`

-------

#### Export request

Resolved from the cohort and the KPI definitions above. Criteria that differ only in their code are rolled up into one filter with a list of codes. `{today}`, `{today-18y}` and `{today-90d}` are replaced by a concrete date and other `{placeholders}` are filled in by the exporter when the request is sent.

**`_type`**

`Procedure,Observation,Patient`

**`_typeFilter`**

```
Procedure?code:in=https://ig.santeon.nl/sim-on-fhir/ValueSet/local-verrichting-codes-nza&date=ge2018-01-01
Observation?code=http://loinc.org|38445-3,http://snomed.info/sct|228273003&date=ge2018-01-01
Patient?gender=male,female

```

**`_elements`**

```
Procedure.code,Procedure.performed[x],Procedure.subject,Observation.code,Observation.value[x],Observation.effective[x],Observation.subject,Patient.gender,Patient.birthDate

```

Every `_typeFilter` and every element above must be covered by the de-identification ruleset, see [De-identification](deidentification.md#core-principles).

-------

#### Request sequence

The export is a sequence of ordinary FHIR requests, executed in this order by the client. They cannot be combined in one Bundle: `$export` is asynchronous and a transaction cannot wait for a Group that is created asynchronously. Fill in every `{placeholder}` in the Group and the Parameters first.

1. **Create the cohort Group.**`PUT [base]/Group/ibd-dataset-cohort`with the[Group](Group-ibd-dataset-cohort.md). A`PUT`fixes the id, so step 3 does not need to read it from a response. A server that creates the Group asynchronously (Bulk Cohort) answers with a status location; poll it until it is complete.
1. **Wait for the Group.**Continue only when the Group exists and its members are resolved.
1. **Start the export.**`POST [base]/Group/ibd-dataset-cohort/$export`with header`Prefer: respond-async`and the[Parameters](Parameters-ibd-dataset-export.md)as body. The answer is a status location.
1. **Wait for the export.**Poll the status location until it returns the manifest.
1. **Download**the files listed in the manifest.

How the de-identification ruleset reaches the server is not part of the Bulk Data specification and is not decided here.

