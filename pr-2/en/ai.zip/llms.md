# santeon.sim-on-fhir#0.1.0: SIM on FHIR(en)

## Pages

* [Home](index.md)
* [FHIR Profiles](profiles.md)
* [Datasets](datasets.md)
* [IBD](ibd-dataset.md)
* [Artifacts Summary](artifacts.md)
* [KPI definitions](kpi-definitions.md)
* [SIM Logical Models](CLMs.md)
* [De-identification](deidentification.md)
* [K3.6.3 Calprotectine voor scopie](K363.md)
* [K3.1.2 Scopie](K312.md)

## Resources

### CodeSystems

* [De-identification Action Code System](CodeSystem-deidentification-action-cs.md)

### ValueSets

* [AlcoholGebruikStatusCodelijst](ValueSet-AlcoholGebruikStatusCodelijst.md)
* [Santeon_MetingNaamCodelijst](ValueSet-Santeon-MetingNaamCodelijst.md)
* [TabakGebruikStatusCodelijst](ValueSet-TabakGebruikStatusCodelijst.md)
* [De-identification Action Value Set](ValueSet-deidentification-action-vs.md)
* [IBD Specialisme-Diagnose Combinaties](ValueSet-local-specialisme-diagnose-codes.md)
* [Verrichting Type Codes NZa (Scopie)](ValueSet-local-verrichting-codes-nza.md)
* [IBD Zorgtype Codes (11 en 21)](ValueSet-local-zorgtype-codes.md)
* [Observation code (SAN KPI)](ValueSet-observationCode-san-kpi.md)
* [Procedure code (SAN KPI)](ValueSet-procedureCode-san-kpi.md)

### Logicals

* [Algemene meting (model)](StructureDefinition-SIMAlgemeneMeting.md)
* [Zorgplan (model)](StructureDefinition-SIMCarePlan.md)
* [Contact (model)](StructureDefinition-SIMContact.md)
* [DBC/Zorgtraject (model)](StructureDefinition-SIMDBC.md)
* [Fasering (model)](StructureDefinition-SIMFasering.md)
* [Medicatieafspraak (model)](StructureDefinition-SIMMedicatieAfspraak.md)
* [Patiënt (model)](StructureDefinition-SIMPatient.md)
* [Tabakgebruik (model)](StructureDefinition-SIMTabakGebruik.md)
* [Verrichting (model)](StructureDefinition-SIMVerrichting.md)
* [Vragenlijstantwoord (model)](StructureDefinition-SIMVragenlijstAntwoord.md)
* [Dataset definition (model)](StructureDefinition-dataset-definition.md)
* [De-identification ruleset (model)](StructureDefinition-deidentification-ruleset.md)
* [KPI definition (model)](StructureDefinition-kpi-definition.md)

### Resource Profiles

* [CarePlan (SAN)](StructureDefinition-carePlan-san.md)
* [Condition (SAN)](StructureDefinition-condition-san.md)
* [Encounter (SAN)](StructureDefinition-encounter-san.md)
* [EpisodeOfCare (SAN)](StructureDefinition-episodeOfCare-san.md)
* [MedicationRequest (SAN)](StructureDefinition-medicationRequest-san.md)
* [Observation (SAN KPI)](StructureDefinition-observation-san-kpi.md)
* [Observation TabakGebruik (SAN)](StructureDefinition-observation-san-tabakgebruik.md)
* [Observation (SAN)](StructureDefinition-observation-san.md)
* [Patient (SAN KPI)](StructureDefinition-patient-san-kpi.md)
* [Patient (SAN)](StructureDefinition-patient-san.md)
* [Procedure (SAN KPI)](StructureDefinition-procedure-san-kpi.md)
* [Procedure (SAN)](StructureDefinition-procedure-san.md)
* [QuestionnaireResponse (SAN)](StructureDefinition-questionnaireResponse-san.md)

### Extensions

* [ObservationDefinition Component](StructureDefinition-od-component.md)

### Binaries

* [alcohol-status-recorded](Binary-alcohol-status-recorded.md)
* [ibd-dataset](Binary-ibd-dataset.md)
* [k312-scopie](Binary-k312-scopie.md)
* [k363-calprotectin-before-scopie](Binary-k363-calprotectin-before-scopie.md)
* [santeon-default](Binary-santeon-default.md)

### Groups

* [IBD cohort](Group-ibd-dataset-cohort.md)

### ImplementationGuides

* [SIM on FHIR](ImplementationGuide-santeon.sim-on-fhir.md)

### ObservationDefinitions

* [od-alcohol-use](ObservationDefinition-od-alcohol-use.md)
* [od-calprotectin](ObservationDefinition-od-calprotectin.md)
* [od-smoking-status](ObservationDefinition-od-smoking-status.md)

### Parameters

* [ibd-dataset-export](Parameters-ibd-dataset-export.md)
